package com.example.dayyy6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Dayyy6Application {

	public static void main(String[] args) {
		SpringApplication.run(Dayyy6Application.class, args);
	}

}
