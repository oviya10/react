package com.example.dayyy6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Dayyy6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
